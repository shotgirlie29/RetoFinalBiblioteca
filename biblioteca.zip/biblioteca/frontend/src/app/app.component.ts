import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="navbar">
      <div class="navbar-brand">
        <span class="brand-icon">📚</span>
        <span class="brand-name">BibliotecaApp</span>
      </div>
      <nav class="navbar-nav">
        <a routerLink="/autores" routerLinkActive="active" class="nav-link">Autores</a>
        <a routerLink="/libros" routerLinkActive="active" class="nav-link">Libros</a>
      </nav>
    </header>

    <main class="main-content">
      <router-outlet />
    </main>

    <footer class="footer">
      <p>BibliotecaApp — DAM 1º — Spring Boot + Angular</p>
    </footer>
  `,
  styles: [`
    :host {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      height: 64px;
      background: var(--color-primary);
      color: white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    }

    .navbar-brand {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 1.25rem;
      font-weight: 700;
      letter-spacing: -0.02em;
    }

    .brand-icon { font-size: 1.5rem; }

    .navbar-nav {
      display: flex;
      gap: 0.25rem;
    }

    .nav-link {
      padding: 0.5rem 1rem;
      color: rgba(255,255,255,0.85);
      text-decoration: none;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.2s;
    }

    .nav-link:hover, .nav-link.active {
      background: rgba(255,255,255,0.15);
      color: white;
    }

    .main-content {
      flex: 1;
      padding: 2rem;
      max-width: 1100px;
      width: 100%;
      margin: 0 auto;
    }

    .footer {
      text-align: center;
      padding: 1rem;
      color: var(--color-muted);
      font-size: 0.875rem;
      border-top: 1px solid var(--color-border);
    }
  `]
})
export class AppComponent {}
